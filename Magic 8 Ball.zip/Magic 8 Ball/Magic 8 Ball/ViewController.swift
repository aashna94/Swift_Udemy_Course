//
//  ViewController.swift
//  Magic 8 Ball
//
//  Created by Aashna Narula on 23/03/19.
//  Copyright © 2019 Aashna Narula. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    
    var randNum: Int = 0
    @IBOutlet var ballImage: UIImageView!
    
    let ar = ["ball1","ball2","ball3","ball4","ball5"]
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        updateBallImage()
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


    @IBAction func askButton(_ sender: Any) {
        updateBallImage()
    }
    
    func updateBallImage() {
        randNum = Int(arc4random_uniform(5))
        ballImage.image = UIImage(named: ar[randNum])
    }
}

