//
//  ViewController.swift
//  Dice App
//
//  Created by Aashna Narula on 22/03/19.
//  Copyright © 2019 Aashna Narula. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet var dice1: UIImageView!
    @IBOutlet var dice2: UIImageView!
    
    let ar = ["dice1","dice2","dice3","dice4","dice5","dice6"]
    var randNum1 : Int = 0
    var randNum2 : Int = 0
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        updateDices()
        
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    @IBAction func RollButtonPressed(_ sender: Any) {
        updateDices()
    }
    
    func updateDices() {
        randNum1 = Int(arc4random_uniform(6))
        randNum2 = Int(arc4random_uniform(6))
        
        dice1.image = UIImage(named: ar[randNum1])
        dice2.image = UIImage(named: ar[randNum2])
    }
}

